class Main {
  public static void main(String[] args) {
    System.out.println("Hello world!");
    int mynumber = 12;
    mynumber = mynumber/5;
    System.out.println(mynumber);
     int myNumber; // creates an int variable calls it myname
     myNumber = 14; // assigns myNumber to 14
     // the first time you assign a value its called initializing
     final int MYNUM = 17; // the word final means the varible is constant


  }
  

}